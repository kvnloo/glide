import { stripAnsi } from '@hermes/shared/ansi'
import { compactNumber } from '@hermes/shared/format'
import type { ToolLabel } from '@hermes/shared/gateway-events'

import {
  LIVE_RENDER_MAX_CHARS,
  LIVE_RENDER_MAX_LINES,
  THINKING_COT_MAX,
  VERBOSE_TRAIL_MAX_CHARS,
  VERBOSE_TRAIL_MAX_LINES
} from '../config/limits.js'
import { VERBS } from '../content/verbs.js'
import { t } from '../i18n/runtime.js'
import type { ThinkingMode } from '../types.js'

const WS_RE = /\s+/g

const renderEstimateLine = (line: string) => {
  const trimmed = line.trim()

  if (trimmed.startsWith('|')) {
    return trimmed
      .split('|')
      .filter(Boolean)
      .map(cell => cell.trim())
      .join('  ')
  }

  return line
    .replace(/!\[(.*?)\]\(([^)\s]+)\)/g, '[image: $1]')
    .replace(/\[(.+?)\]\((https?:\/\/[^\s)]+)\)/g, '$1')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/(?<!\w)__(.+?)__(?!\w)/g, '$1')
    .replace(/\*(.+?)\*/g, '$1')
    .replace(/(?<!\w)_(.+?)_(?!\w)/g, '$1')
    .replace(/~~(.+?)~~/g, '$1')
    .replace(/==(.+?)==/g, '$1')
    .replace(/\[\^([^\]]+)\]/g, '[$1]')
    .replace(/^#{1,6}\s+/, '')
    .replace(/^\s*[-*+]\s+\[( |x|X)\]\s+/, (_m, checked: string) => `• [${checked.toLowerCase() === 'x' ? 'x' : ' '}] `)
    .replace(/^\s*[-*+]\s+/, '• ')
    .replace(/^\s*(\d+)\.\s+/, '$1. ')
    .replace(/^\s*(?:>\s*)+/, '│ ')
}

export const compactPreview = (s: string, max: number) => {
  const one = s.replace(WS_RE, ' ').trim()

  return !one ? '' : one.length > max ? one.slice(0, max - 1) + '…' : one
}

export const estimateTokensRough = (text: string) => (!text ? 0 : (text.length + 3) >> 2)

export const edgePreview = (s: string, head = 16, tail = 28) => {
  const one = s.replace(WS_RE, ' ').trim().replace(/\]\]/g, '] ]')

  return !one
    ? ''
    : one.length <= head + tail + 4
      ? one
      : `${one.slice(0, head).trimEnd()}.. ${one.slice(-tail).trimStart()}`
}

export const pasteTokenLabel = (text: string, lineCount: number) => {
  const preview = edgePreview(text)

  const chip = t('libText.text.pasteLinesChip', compactNumber(lineCount))

  if (!preview) {
    return `[[ ${chip} ]]`
  }

  const [head = preview, tail = ''] = preview.split('.. ', 2)

  return tail ? `[[ ${head.trimEnd()}.. ${chip} .. ${tail.trimStart()} ]]` : `[[ ${preview} ${chip} ]]`
}

const THINKING_STATUS_RE = new RegExp(`^(?:${VERBS.join('|')})\\.{0,3}$`, 'i')
const THINKING_STATUS_CHUNK_RE = new RegExp(`[^A-Za-z\n]+\\s*(?:${VERBS.join('|')})\\.{0,3}\\s*`, 'giu')

export const cleanThinkingText = (reasoning: string) =>
  reasoning
    .split('\n')
    .map(line => line.replace(THINKING_STATUS_CHUNK_RE, '').trim())
    .filter(line => line && !THINKING_STATUS_RE.test(line.replace(/\.\.\.$/, '').trim()))
    .join('\n')
    .replace(/([^\n])(?=\*\*[^*\n][^\n]*?\*\*)/g, '$1\n\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()

// cleanThinkingText runs several full-string regex passes (split/map/filter/join/replace).
// reasoning grows on every streamed token, so without a pre-bound this re-cleans the whole
// accumulated string on every chunk — O(n) work per token, O(n^2) over a stream. Only the
// tail is ever displayed (boundedLiveRenderText caps it further downstream), so bound the
// input here first. Headroom over LIVE_RENDER_MAX_CHARS keeps line-boundary trimming inside
// cleanThinkingText accurate even after slicing mid-line.
const THINKING_CLEAN_TAIL_BOUND = LIVE_RENDER_MAX_CHARS * 1.5

export const thinkingPreview = (reasoning: string, mode: ThinkingMode, max: number = THINKING_COT_MAX) => {
  const bounded = reasoning.length > THINKING_CLEAN_TAIL_BOUND ? reasoning.slice(-THINKING_CLEAN_TAIL_BOUND) : reasoning
  const raw = cleanThinkingText(bounded)

  return !raw || mode === 'collapsed' ? '' : mode === 'full' ? raw : compactPreview(raw.replace(WS_RE, ' '), max)
}

export const boundedLiveRenderText = (
  text: string,
  { maxChars = LIVE_RENDER_MAX_CHARS, maxLines = LIVE_RENDER_MAX_LINES } = {}
) => boundedRenderText(text, t('libText.text.showingLiveTail'), { maxChars, maxLines })

const boundedRenderText = (
  text: string,
  labelPrefix: string,
  { maxChars, maxLines }: { maxChars: number; maxLines: number }
) => {
  if (text.length <= maxChars && text.split('\n', maxLines + 1).length <= maxLines) {
    return text
  }

  let start = 0
  let idx = text.length

  for (let seen = 0; seen < maxLines && idx > 0; seen++) {
    idx = text.lastIndexOf('\n', idx - 1)
    start = idx < 0 ? 0 : idx + 1

    if (idx < 0) {
      break
    }
  }

  const lineStart = start
  start = Math.max(lineStart, text.length - maxChars)

  if (start > lineStart) {
    const nextBreak = text.indexOf('\n', start)

    if (nextBreak >= 0 && nextBreak < text.length - 1) {
      start = nextBreak + 1
    }
  }

  const tail = text.slice(start).trimStart()
  const omittedLines = countNewlines(text, start)
  const omittedChars = Math.max(0, text.length - tail.length)

  const label =
    omittedLines > 0
      ? t('libText.text.omittedLinesChars', labelPrefix, compactNumber(omittedLines), compactNumber(omittedChars))
      : t('libText.text.omittedChars', labelPrefix, compactNumber(omittedChars))

  return `${label}\n${tail}`
}

const countNewlines = (text: string, end: number) => {
  let count = 0

  for (let i = 0; i < end; i++) {
    if (text.charCodeAt(i) === 10) {
      count++
    }
  }

  return count
}

export const stripTrailingPasteNewlines = (text: string) => (/[^\n]/.test(text) ? text.replace(/\n+$/, '') : text)

export const toolTrailLabel = (name: string) =>
  name
    .split('_')
    .filter(Boolean)
    .map(p => p[0]!.toUpperCase() + p.slice(1))
    .join(' ') || name

export const formatToolCall = (name: string, context = '') => {
  const label = toolTrailLabel(name)
  const preview = compactPreview(context, 64)

  return preview ? `${label}("${preview}")` : label
}

/** One row's worth of a bridged call: the gateway already phrased it, preview included. */
export const formatToolLabel = (label: ToolLabel) =>
  `${label.emoji} ${compactPreview(label.preview ? `${label.text}  ${label.preview}` : label.text, 72)}`

export const formatToolLabels = (labels: readonly ToolLabel[]) => {
  const [first, ...rest] = labels

  if (first === undefined) {
    return ''
  }

  return rest.length > 0 ? `${formatToolLabel(first)} +${rest.length}` : formatToolLabel(first)
}

/** A finished trail row for an already-phrased call. */
export const toolTrailLine = (call: string, error?: boolean, note?: string, duration?: number) => {
  const detail = compactPreview(note ?? '', 72)
  const took = duration !== undefined ? ` (${duration.toFixed(1)}s)` : ''

  return `${call}${took}${detail ? ` :: ${detail}` : ''} ${error ? '✗' : '✓'}`
}

export const buildToolTrailLine = (name: string, context: string, error?: boolean, note?: string, duration?: number) =>
  toolTrailLine(formatToolCall(name, context), error, note, duration)

const verboseToolBlock = (label: string, text?: string) => {
  const body = (text ?? '').trim()

  // Persisted trail blocks are kept all session and rendered expanded by
  // default — cap to a small readable preview (NOT the 16KB live-render
  // budget) so a large tool output can't balloon the Ink render tree and
  // silently OOM-kill the TUI. See VERBOSE_TRAIL_MAX_CHARS (#34095).
  return body
    ? `${label}:\n${boundedLiveRenderText(body, {
        maxChars: VERBOSE_TRAIL_MAX_CHARS,
        maxLines: VERBOSE_TRAIL_MAX_LINES
      })}`
    : ''
}

/** The Args and Result blocks for an already-phrased call. */
export const verboseToolTrailLine = (
  call: string,
  error?: boolean,
  duration?: number,
  argsText?: string,
  resultText?: string
) => {
  const detail = [
    verboseToolBlock(t('libText.text.argsLabel'), argsText),
    verboseToolBlock(error ? t('libText.text.errorLabel') : t('libText.text.resultLabel'), resultText)
  ]
    .filter(Boolean)
    .join('\n')

  const took = duration !== undefined ? ` (${duration.toFixed(1)}s)` : ''

  return `${call}${took}${detail ? ` :: ${detail}` : ''} ${error ? '✗' : '✓'}`
}

export const buildVerboseToolTrailLine = (
  name: string,
  context: string,
  error?: boolean,
  duration?: number,
  argsText?: string,
  resultText?: string
) => verboseToolTrailLine(formatToolCall(name, context), error, duration, argsText, resultText)

export const isToolTrailResultLine = (line: string) => line.endsWith(' ✓') || line.endsWith(' ✗')

export const parseToolTrailResultLine = (line: string) => {
  if (!isToolTrailResultLine(line)) {
    return null
  }

  const mark = line.endsWith(' ✗') ? '✗' : '✓'
  const body = line.slice(0, -2)
  const sep = body.indexOf(' :: ')

  if (sep >= 0) {
    return { call: body.slice(0, sep), detail: body.slice(sep + 4), mark }
  }

  const legacy = body.indexOf(': ')

  if (legacy > 0) {
    return { call: body.slice(0, legacy), detail: body.slice(legacy + 2), mark }
  }

  return { call: body, detail: '', mark }
}

export const splitToolDuration = (call: string) => {
  const match = call.match(/^(.*?)( \(\d+(?:\.\d)?s\))$/)

  return match ? { label: match[1]!, duration: match[2]! } : { label: call, duration: '' }
}

export const isTransientTrailLine = (line: string) => line.startsWith('drafting ') || line === 'analyzing tool output…'

export const sameToolTrailGroup = (label: string, entry: string) =>
  entry === `${label} ✓` ||
  entry === `${label} ✗` ||
  entry.startsWith(`${label}(`) ||
  entry.startsWith(`${label} ::`) ||
  entry.startsWith(`${label}:`)

export const lastCotTrailIndex = (trail: readonly string[]) => {
  for (let i = trail.length - 1; i >= 0; i--) {
    if (!isToolTrailResultLine(trail[i]!)) {
      return i
    }
  }

  return -1
}

export const estimateRows = (text: string, w: number, compact = false) => {
  let fence: { char: '`' | '~'; len: number } | null = null
  let rows = 0

  for (const raw of text.split('\n')) {
    const line = stripAnsi(raw)
    const maybeFence = line.match(/^\s*(`{3,}|~{3,})(.*)$/)

    if (maybeFence) {
      const marker = maybeFence[1]!
      const lang = maybeFence[2]!.trim()

      if (!fence) {
        fence = { char: marker[0] as '`' | '~', len: marker.length }

        if (lang) {
          rows += Math.ceil((`─ ${lang}`.length || 1) / w)
        }
      } else if (marker[0] === fence.char && marker.length >= fence.len) {
        fence = null
      }

      continue
    }

    const inCode = Boolean(fence)
    const trimmed = line.trim()

    if (!inCode && trimmed.startsWith('|') && /^[|\s:-]+$/.test(trimmed)) {
      continue
    }

    const rendered = inCode ? line : renderEstimateLine(line)

    if (compact && !rendered.trim()) {
      continue
    }

    rows += Math.ceil((rendered.length || 1) / w)
  }

  return Math.max(1, rows)
}

/**
 * Render an unanswered clarify prompt (timed out, or cancelled with Esc/Ctrl+C)
 * as a persistent transcript block.  Every question on its own line, answered
 * ones keeping their locked answer (partials survive a timeout server-side, so
 * the record must show what was actually sent).  `reason` states why the
 * prompt ended ("timed out", "cancelled").
 */
export const formatAbandonedClarify = (
  questions: { multiSelect?: boolean; qid: string; question: string }[],
  answers: Record<string, string>,
  reason: string
) => {
  const lines = questions.map(q => {
    const answer = answers[q.qid]

    return answer
      ? `  ${t('libText.text.clarifyAnswered', q.question, clarifyAnswerText(answer, q.multiSelect))}`
      : `  ${t('libText.text.clarifyUnanswered', q.question)}`
  })

  return [
    t('libText.text.clarifyHead', questions.length),
    ...lines,
    `  ${t('libText.text.clarifyReason', reason)}`
  ].join('\n')
}

const clarifyAnswerItems = (answer: string): null | string[] => {
  try {
    const parsed: unknown = JSON.parse(answer)

    return Array.isArray(parsed) ? parsed.map(String) : null
  } catch {
    return null
  }
}

/**
 * Cursor/draft restore for re-visiting an answered batch clarify question
 * (Tab/Shift-Tab): a choice answer puts the cursor back on its row; an
 * answer that matches no choice was typed via Other, so the cursor lands on
 * the Other row (index = choices.length) with the text staged for editing.
 * Unanswered questions restore to a clean cursor.
 */
export const clarifyRevisitState = (
  choices: readonly string[],
  answer: string | undefined,
  multiSelect = false
): { custom: string; picked: string[]; sel: number } => {
  if (answer === undefined || answer === '') {
    return { custom: '', picked: [], sel: 0 }
  }

  const items = multiSelect ? clarifyAnswerItems(answer) : null

  if (items) {
    const custom = items.filter(item => !choices.includes(item)).join(', ')

    return { custom, picked: items.filter(item => choices.includes(item)), sel: custom ? choices.length : 0 }
  }

  const choiceIndex = choices.indexOf(answer)

  if (choiceIndex >= 0) {
    return { custom: '', picked: [], sel: choiceIndex }
  }

  return { custom: answer, picked: [], sel: choices.length > 0 ? choices.length : 0 }
}

export const clarifyAnswerText = (answer: string, multiSelect?: boolean) => {
  const items = multiSelect ? clarifyAnswerItems(answer) : null

  return items ? items.join(', ') : answer
}

export const flat = (r: Record<string, string[]>) => Object.values(r).flat()

export const pick = <T>(a: T[]) => a[Math.floor(Math.random() * a.length)]!

export const isPasteBackedText = (text: string) =>
  /\[\[paste:\d+(?:[^\n]*?)\]\]|\[paste #\d+ (?:attached|excerpt)(?:[^\n]*?)\]/.test(text)
