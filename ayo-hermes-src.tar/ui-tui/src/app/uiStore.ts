import { atom, computed } from 'nanostores'

import { MOUSE_TRACKING } from '../config/env.js'
import { ZERO } from '../domain/usage.js'
import { t } from '../i18n/runtime.js'
import { bootTheme } from '../lib/themeBoot.js'
import { DEFAULT_THEME } from '../theme.js'

import { DEFAULT_INDICATOR_STYLE, type UiState } from './interfaces.js'

const buildUiState = (): UiState => ({
  battery: false,
  batteryStatus: null,
  bgTasks: new Set(),
  busy: false,
  busyInputMode: 'queue',
  compact: false,
  compacting: false,
  destructiveSlashConfirm: true,
  detailsMode: 'collapsed',
  detailsModeCommandOverride: false,
  focusView: false,
  indicatorStyle: DEFAULT_INDICATOR_STYLE,
  info: null,
  liveSessionCount: 0,
  inlineDiffs: true,
  mouseTracking: MOUSE_TRACKING,
  notice: null,
  pasteCollapseLines: 5,
  pasteCollapseChars: 2000,
  sections: {},
  sessionTitle: '',
  showReasoning: false,
  sid: null,
  status: t('status.summoning'),
  statusBar: 'top',
  storedSid: null,
  statusBarFields: null,
  streaming: true,
  timestamps: false,
  // Last session's resolved theme paints frame one (flash-free boot, like
  // the desktop's hermes-boot-* keys); DEFAULT_THEME only on first launch.
  theme: bootTheme ?? DEFAULT_THEME,
  usage: ZERO
})

export const $uiState = atom<UiState>(buildUiState())

export const $uiTheme = computed($uiState, state => state.theme)
export const $uiSessionId = computed($uiState, state => state.sid)

export const getUiState = () => $uiState.get()

// The folder a user-typed path is relative to: the session's, else the one `hermes --tui` was
// launched from. Never this process's cwd (the ui-tui install) or the shared gateway's.
export const sessionCwd = (): string | undefined => $uiState.get().info?.cwd || process.env.HERMES_CWD || undefined

export const patchUiState = (next: Partial<UiState> | ((state: UiState) => UiState)) =>
  $uiState.set(typeof next === 'function' ? next($uiState.get()) : { ...$uiState.get(), ...next })

export const resetUiState = () => $uiState.set(buildUiState())
