import { beforeEach, describe, expect, it, vi } from 'vitest'

import { $uiState, patchUiState, resetUiState } from '../app/uiStore.js'
import {
  applyDisplay,
  hydrateFullConfig,
  type McpRevState,
  normalizeBusyInputMode,
  normalizeIndicatorStyle,
  normalizeMouseTracking,
  normalizeStatusBar,
  syncMcpReload
} from '../app/useConfigSync.js'

describe('applyDisplay', () => {
  beforeEach(() => {
    resetUiState()
  })

  it('fans every display flag out to $uiState and the bell callback', () => {
    const setBell = vi.fn()

    applyDisplay(
      {
        config: {
          display: {
            bell_on_complete: true,
            details_mode: 'expanded',
            inline_diffs: false,
            show_reasoning: true,
            streaming: false,
            tui_compact: true,
            tui_statusbar: false
          }
        }
      },
      setBell
    )

    const s = $uiState.get()
    expect(setBell).toHaveBeenCalledWith(true)
    expect(s.compact).toBe(true)
    expect(s.detailsMode).toBe('expanded')
    expect(s.inlineDiffs).toBe(false)
    expect(s.showReasoning).toBe(true)
    expect(s.statusBar).toBe('off')
    expect(s.streaming).toBe(false)
  })

  it('hydrates the destructive slash confirmation policy from approvals', () => {
    const setBell = vi.fn()

    applyDisplay(
      {
        config: {
          approvals: { destructive_slash_confirm: false },
          display: {}
        }
      },
      setBell
    )

    expect($uiState.get().destructiveSlashConfirm).toBe(false)

    applyDisplay(
      {
        config: {
          approvals: { destructive_slash_confirm: true },
          display: {}
        }
      },
      setBell
    )

    expect($uiState.get().destructiveSlashConfirm).toBe(true)
  })

  it('defaults destructive slash confirmation on and preserves it across config RPC failure', () => {
    const setBell = vi.fn()

    applyDisplay({ config: { display: {} } }, setBell)
    expect($uiState.get().destructiveSlashConfirm).toBe(true)

    applyDisplay(
      {
        config: {
          approvals: { destructive_slash_confirm: false },
          display: {}
        }
      },
      setBell
    )
    applyDisplay(null, setBell)

    expect($uiState.get().destructiveSlashConfirm).toBe(false)
  })

  it('applies v1 parity defaults when display fields are missing', () => {
    const setBell = vi.fn()

    applyDisplay({ config: { display: {} } }, setBell)

    const s = $uiState.get()
    expect(setBell).toHaveBeenCalledWith(false)
    expect(s.inlineDiffs).toBe(true)
    expect(s.showReasoning).toBe(false)
    expect(s.statusBar).toBe('top')
    expect(s.streaming).toBe(true)
    expect(s.sections).toEqual({})
  })

  it('parses display.sections into per-section overrides', () => {
    const setBell = vi.fn()

    applyDisplay(
      {
        config: {
          display: {
            details_mode: 'collapsed',
            sections: {
              activity: 'hidden',
              tools: 'expanded',
              thinking: 'expanded',
              bogus: 'expanded'
            }
          }
        }
      },
      setBell
    )

    const s = $uiState.get()
    expect(s.detailsMode).toBe('collapsed')
    expect(s.sections).toEqual({
      activity: 'hidden',
      tools: 'expanded',
      thinking: 'expanded'
    })
  })

  it('drops invalid section modes', () => {
    const setBell = vi.fn()

    applyDisplay(
      {
        config: {
          display: {
            sections: { tools: 'maximised' as unknown as string, activity: 'hidden' }
          }
        }
      },
      setBell
    )

    expect($uiState.get().sections).toEqual({ activity: 'hidden' })
  })
})

describe('normalizeStatusBar', () => {
  it('maps legacy bool + on alias to top/off', () => {
    expect(normalizeStatusBar(true)).toBe('top')
    expect(normalizeStatusBar(false)).toBe('off')
    expect(normalizeStatusBar('on')).toBe('top')
  })

  it('passes through the canonical enum', () => {
    expect(normalizeStatusBar('off')).toBe('off')
    expect(normalizeStatusBar('top')).toBe('top')
    expect(normalizeStatusBar('bottom')).toBe('bottom')
  })

  it('defaults missing/unknown values to top', () => {
    expect(normalizeStatusBar(undefined)).toBe('top')
    expect(normalizeStatusBar(null)).toBe('top')
    expect(normalizeStatusBar('sideways')).toBe('top')
    expect(normalizeStatusBar(42)).toBe('top')
  })

  it('trims whitespace and folds case', () => {
    expect(normalizeStatusBar(' Bottom ')).toBe('bottom')
    expect(normalizeStatusBar('TOP')).toBe('top')
    expect(normalizeStatusBar('  on  ')).toBe('top')
    expect(normalizeStatusBar('OFF')).toBe('off')
  })
})

describe('normalizeMouseTracking', () => {
  it('defaults to all and prefers canonical mouse_tracking over legacy tui_mouse', () => {
    expect(normalizeMouseTracking({})).toBe('all')
    expect(normalizeMouseTracking({ mouse_tracking: false })).toBe('off')
    expect(normalizeMouseTracking({ mouse_tracking: 0 })).toBe('off')
    expect(normalizeMouseTracking({ mouse_tracking: 'off' })).toBe('off')
    expect(normalizeMouseTracking({ mouse_tracking: 'false' })).toBe('off')
    expect(normalizeMouseTracking({ mouse_tracking: null, tui_mouse: false })).toBe('all')
    expect(normalizeMouseTracking({ mouse_tracking: true, tui_mouse: false })).toBe('all')
    expect(normalizeMouseTracking({ tui_mouse: false })).toBe('off')
  })

  it('accepts preset strings (wheel/buttons/all) and their aliases', () => {
    expect(normalizeMouseTracking({ mouse_tracking: 'wheel' })).toBe('wheel')
    expect(normalizeMouseTracking({ mouse_tracking: 'scroll' })).toBe('wheel')
    expect(normalizeMouseTracking({ mouse_tracking: 'buttons' })).toBe('buttons')
    expect(normalizeMouseTracking({ mouse_tracking: 'click' })).toBe('buttons')
    expect(normalizeMouseTracking({ mouse_tracking: 'all' })).toBe('all')
    expect(normalizeMouseTracking({ mouse_tracking: 'full' })).toBe('all')
    expect(normalizeMouseTracking({ mouse_tracking: 'on' })).toBe('all')
    expect(normalizeMouseTracking({ mouse_tracking: ' WHEEL ' })).toBe('wheel')
  })

  it('falls back to all for unknown strings', () => {
    expect(normalizeMouseTracking({ mouse_tracking: 'rainbows' })).toBe('all')
  })
})

describe('normalizeBusyInputMode', () => {
  it('passes through the canonical CLI parity values', () => {
    expect(normalizeBusyInputMode('queue')).toBe('queue')
    expect(normalizeBusyInputMode('steer')).toBe('steer')
    expect(normalizeBusyInputMode('interrupt')).toBe('interrupt')
  })

  it('trims and lowercases input', () => {
    expect(normalizeBusyInputMode(' Queue ')).toBe('queue')
    expect(normalizeBusyInputMode('STEER')).toBe('steer')
  })

  it('defaults to queue for missing/unknown values (TUI-only override)', () => {
    // CLI / messaging adapters keep `interrupt` as the framework default
    // (see hermes_cli/config.py + tui_gateway/server.py::_load_busy_input_mode);
    // the TUI ships `queue` because typing a follow-up while the agent
    // streams is the common authoring pattern and an unintended interrupt
    // loses work.
    expect(normalizeBusyInputMode(undefined)).toBe('queue')
    expect(normalizeBusyInputMode(null)).toBe('queue')
    expect(normalizeBusyInputMode('')).toBe('queue')
    expect(normalizeBusyInputMode('drop')).toBe('queue')
    expect(normalizeBusyInputMode(42)).toBe('queue')
  })
})

describe('normalizeIndicatorStyle', () => {
  it('passes through the canonical enum', () => {
    expect(normalizeIndicatorStyle('kaomoji')).toBe('kaomoji')
    expect(normalizeIndicatorStyle('emoji')).toBe('emoji')
    expect(normalizeIndicatorStyle('unicode')).toBe('unicode')
    expect(normalizeIndicatorStyle('ascii')).toBe('ascii')
  })

  it('trims and lowercases input', () => {
    expect(normalizeIndicatorStyle(' Emoji ')).toBe('emoji')
    expect(normalizeIndicatorStyle('UNICODE')).toBe('unicode')
  })

  it('defaults to kaomoji for missing/unknown values', () => {
    expect(normalizeIndicatorStyle(undefined)).toBe('kaomoji')
    expect(normalizeIndicatorStyle(null)).toBe('kaomoji')
    expect(normalizeIndicatorStyle('')).toBe('kaomoji')
    expect(normalizeIndicatorStyle('sparkle')).toBe('kaomoji')
    expect(normalizeIndicatorStyle(42)).toBe('kaomoji')
  })
})

describe('applyDisplay → busy_input_mode', () => {
  beforeEach(() => {
    resetUiState()
  })

  it('threads display.busy_input_mode into $uiState', () => {
    const setBell = vi.fn()

    applyDisplay({ config: { display: { busy_input_mode: 'queue' } } }, setBell)
    expect($uiState.get().busyInputMode).toBe('queue')

    applyDisplay({ config: { display: { busy_input_mode: 'steer' } } }, setBell)
    expect($uiState.get().busyInputMode).toBe('steer')
  })
})

describe('applyDisplay → tui_status_indicator', () => {
  beforeEach(() => {
    resetUiState()
  })

  it('threads display.tui_status_indicator into $uiState', () => {
    const setBell = vi.fn()

    applyDisplay({ config: { display: { tui_status_indicator: 'emoji' } } }, setBell)
    expect($uiState.get().indicatorStyle).toBe('emoji')

    applyDisplay({ config: { display: { tui_status_indicator: 'unicode' } } }, setBell)
    expect($uiState.get().indicatorStyle).toBe('unicode')
  })
})

// Regressions from Copilot review on #19835: the config-hydration path
// for voice.record_key was untested, so a future regression in the
// hydration or mtime-reapply wiring would slip past the suite.
describe('applyDisplay → voice.record_key (#18994)', () => {
  beforeEach(() => {
    resetUiState()
  })

  it('parses voice.record_key and pushes it through the setter', () => {
    const setBell = vi.fn()
    const setVoiceRecordKey = vi.fn()

    applyDisplay({ config: { display: {}, voice: { record_key: 'ctrl+space' } } }, setBell, setVoiceRecordKey)

    expect(setVoiceRecordKey).toHaveBeenCalledWith(
      expect.objectContaining({ ch: 'space', mod: 'ctrl', named: 'space', raw: 'ctrl+space' })
    )
  })

  it('falls back to the documented default when voice.record_key is missing', () => {
    const setBell = vi.fn()
    const setVoiceRecordKey = vi.fn()

    applyDisplay({ config: { display: {} } }, setBell, setVoiceRecordKey)

    expect(setVoiceRecordKey).toHaveBeenCalledWith(expect.objectContaining({ ch: 'b', mod: 'ctrl', raw: 'ctrl+b' }))
  })

  it('does not reset voiceRecordKey when cfg is null (transient RPC failure)', () => {
    const setBell = vi.fn()
    const setVoiceRecordKey = vi.fn()

    // quietRpc() collapses request failures to null. Resetting the
    // cached shortcut on every null would clobber a custom binding
    // after one transient error until the next successful poll
    // (Copilot round-8 review on #19835).
    applyDisplay(null, setBell, setVoiceRecordKey)

    expect(setVoiceRecordKey).not.toHaveBeenCalled()
    // bell is still applied (defaults to false on null), so the setter
    // runs — we specifically only skip voiceRecordKey.
    expect(setBell).toHaveBeenCalledWith(false)
  })
})

// Review on #20379 (finding 1): an MCP config revision must never be acked
// before the server confirms it was LOADED. The old poll advanced its
// accepted revision first and fired reload.mcp second — a reload that failed
// (quietRpc → null) left the revision recorded as applied, and no subsequent
// poll retried it until an unrelated MCP edit.
describe('syncMcpReload (revision-aware ack)', () => {
  const gwOk = (payload: unknown) =>
    ({ request: vi.fn(() => Promise.resolve(payload)), on: vi.fn(), off: vi.fn() }) as any

  const freshState = (accepted = 'rev-a'): McpRevState => ({ accepted, inFlight: false })

  it('advances accepted only after the server confirms the reload', async () => {
    const gw = gwOk({ status: 'reloaded', loaded_rev: 'rev-b' })
    const state = freshState()
    const onReloaded = vi.fn()

    await syncMcpReload(gw, 's1', 'rev-b', state, onReloaded)

    expect(gw.request).toHaveBeenCalledWith('reload.mcp', { confirm: true, rev: 'rev-b', session_id: 's1' })
    expect(state.accepted).toBe('rev-b')
    expect(onReloaded).toHaveBeenCalledTimes(1)
  })

  it('does NOT advance accepted when the reload RPC fails — next poll retries', async () => {
    const gw = { request: vi.fn(() => Promise.reject(new Error('flapping server'))), on: vi.fn(), off: vi.fn() } as any
    const state = freshState()
    const onReloaded = vi.fn()

    await syncMcpReload(gw, 's1', 'rev-b', state, onReloaded)

    // The exact failure sequence from the review: reload fails, revision
    // must remain un-acked so the next tick retries it.
    expect(state.accepted).toBe('rev-a')
    expect(state.inFlight).toBe(false)
    expect(onReloaded).not.toHaveBeenCalled()

    // Next poll tick: the server recovered — the SAME revision goes through.
    gw.request = vi.fn(() => Promise.resolve({ status: 'reloaded', loaded_rev: 'rev-b' }))
    await syncMcpReload(gw, 's1', 'rev-b', state, onReloaded)
    expect(state.accepted).toBe('rev-b')
    expect(onReloaded).toHaveBeenCalledTimes(1)
  })

  it('does not advance on confirm_required (reload did not happen)', async () => {
    const gw = gwOk({ message: 'confirm first', status: 'confirm_required' })
    const state = freshState()

    await syncMcpReload(gw, 's1', 'rev-b', state)

    expect(state.accepted).toBe('rev-a')
  })

  it('records the server-reported loaded_rev, not the requested rev', async () => {
    // A config edit raced the reload: the server re-hashed after discovery
    // and loaded rev-c. Recording rev-c (not rev-b) makes the next poll a
    // no-op instead of an immediate redundant reload.
    const gw = gwOk({ status: 'reloaded', loaded_rev: 'rev-c' })
    const state = freshState()

    await syncMcpReload(gw, 's1', 'rev-b', state)

    expect(state.accepted).toBe('rev-c')
  })

  it('is a no-op when the revision is already accepted or empty', async () => {
    const gw = gwOk({ status: 'reloaded' })
    const state = freshState()

    await syncMcpReload(gw, 's1', 'rev-a', state)
    await syncMcpReload(gw, 's1', '', state)

    expect(gw.request).not.toHaveBeenCalled()
  })

  it('does not stack requests while one is in flight', async () => {
    let resolveFirst!: (v: unknown) => void

    const gw = {
      request: vi.fn(() => new Promise(res => (resolveFirst = res))),
      on: vi.fn(),
      off: vi.fn()
    } as any

    const state = freshState()

    const first = syncMcpReload(gw, 's1', 'rev-b', state)

    // Second tick while the first RPC is outstanding: swallowed.
    await syncMcpReload(gw, 's1', 'rev-b', state)
    expect(gw.request).toHaveBeenCalledTimes(1)

    resolveFirst({ status: 'reloaded', loaded_rev: 'rev-b' })
    await first
    expect(state.accepted).toBe('rev-b')
  })
})

// Round-12 Copilot review regression on #19835: the live mtime-reload
// path was previously untested, so a regression in the polling/RPC
// wiring to applyDisplay would only be visible at runtime. The fetch
// + apply body is now shared as ``hydrateFullConfig()``, exercised
// directly from both the initial hydration and the poll-tick body.
describe('hydrateFullConfig', () => {
  it('hydrates the session busy preference instead of profile defaults and preserves it on read failure', async () => {
    patchUiState({ sid: 'owner', busyInputMode: 'queue' })

    const request = vi.fn(async (_method: string, params: any) =>
      params.key === 'busy' ? { value: 'steer' } : { config: { display: { busy_input_mode: 'interrupt' } } }
    )

    const gw = { isCanonical: true, request } as any
    const scope = { sid: 'owner', isCurrent: () => true }
    await hydrateFullConfig(gw, vi.fn(), undefined, undefined, scope)
    expect(request).toHaveBeenCalledWith('config.get', { key: 'full', session_id: 'owner' })
    expect(request).toHaveBeenCalledWith('config.get', { key: 'busy', session_id: 'owner' })
    expect($uiState.get().busyInputMode).toBe('steer')
    request.mockImplementation(async (_method, params) => {
      if (params.key === 'busy') {throw new Error('disconnected')}

      return { config: { display: { busy_input_mode: 'interrupt' } } }
    })
    await hydrateFullConfig(gw, vi.fn(), undefined, undefined, scope)
    expect($uiState.get().busyInputMode).toBe('steer')
  })

  it('discards delayed full and busy hydration after focus changes', async () => {
    patchUiState({ sid: 'old', busyInputMode: 'queue' })
    let current = true
    const replies: Array<(value: any) => void> = []

    const gw = {
      isCanonical: true,
      request: vi.fn(() => new Promise(resolve => replies.push(resolve)))
    } as any

    const setBell = vi.fn()
    const pending = hydrateFullConfig(gw, setBell, undefined, undefined, { sid: 'old', isCurrent: () => current })
    current = false
    patchUiState({ sid: 'new', busyInputMode: 'interrupt' })

    for (const reply of replies) {reply({ config: { display: { busy_input_mode: 'steer' } }, value: 'steer' })}
    await pending
    expect(setBell).not.toHaveBeenCalled()
    expect($uiState.get().busyInputMode).toBe('interrupt')
  })

  beforeEach(() => {
    resetUiState()
  })

  const makeFakeGw = (payload: unknown) =>
    ({
      request: vi.fn(() => Promise.resolve(payload)),
      on: vi.fn(),
      off: vi.fn()
    }) as any

  it('re-applies voice.record_key from a fresh config.get full response', async () => {
    const gw = makeFakeGw({ config: { display: {}, voice: { record_key: 'ctrl+o' } } })
    const setBell = vi.fn()
    const setVoiceRecordKey = vi.fn()

    await hydrateFullConfig(gw, setBell, setVoiceRecordKey)

    expect(gw.request).toHaveBeenCalledWith('config.get', { key: 'full' })
    expect(setVoiceRecordKey).toHaveBeenCalledWith(expect.objectContaining({ ch: 'o', mod: 'ctrl', raw: 'ctrl+o' }))
    expect(setBell).toHaveBeenCalledWith(false)
  })

  it('reapplies the latest value on each invocation (mtime-reload semantics)', async () => {
    const gw = makeFakeGw({ config: { display: {}, voice: { record_key: 'ctrl+b' } } })
    const setBell = vi.fn()
    const setVoiceRecordKey = vi.fn()

    await hydrateFullConfig(gw, setBell, setVoiceRecordKey)
    expect(setVoiceRecordKey).toHaveBeenLastCalledWith(expect.objectContaining({ ch: 'b' }))

    // Simulate a config edit: gw now returns a new shortcut.
    gw.request = vi.fn(() => Promise.resolve({ config: { display: {}, voice: { record_key: 'alt+space' } } }))

    await hydrateFullConfig(gw, setBell, setVoiceRecordKey)
    expect(setVoiceRecordKey).toHaveBeenLastCalledWith(
      expect.objectContaining({ ch: 'space', mod: 'alt', named: 'space' })
    )
  })

  it('leaves cached voiceRecordKey untouched when the RPC fails', async () => {
    const gw = { request: vi.fn(() => Promise.reject(new Error('boom'))), on: vi.fn(), off: vi.fn() } as any
    const setBell = vi.fn()
    const setVoiceRecordKey = vi.fn()

    const result = await hydrateFullConfig(gw, setBell, setVoiceRecordKey)

    // quietRpc() swallows the error and returns null; applyDisplay
    // sees cfg=null and skips the voice setter (Copilot round-8).
    expect(result).toBeNull()
    expect(setVoiceRecordKey).not.toHaveBeenCalled()
    // bell setter still fires — applyDisplay's null-cfg path applies
    // the documented bell default (false).
    expect(setBell).toHaveBeenCalledWith(false)
  })

  it('threads through without a voice setter (back-compat call sites)', async () => {
    const gw = makeFakeGw({ config: { display: { bell_on_complete: true } } })
    const setBell = vi.fn()

    // No third arg — applyDisplay must not throw and must still apply
    // display flags (round-2 / round-8 invariant).
    await expect(hydrateFullConfig(gw, setBell)).resolves.toBeTruthy()
    expect(setBell).toHaveBeenCalledWith(true)
  })
})
